2. Performance measure of a business senario
Stress Test: LoginAndSearchItemPerformanceTest.jmx
 - Scenario: a user will login every second, 
and then do the following:
   - search, 
   - will try to pick a pet
   - logout
this will be sustained for 25mins.

Analysis of Result:
- based on the graph, response_time_graph_.png, login and pet/findByStatus api are having a peak response time of about 7 seconds to 9 seconds even though I'm using the same user and querying the same data.
- suggestions:
  - Api: some form of temporary caching that can be implemented server side if the same data is being queried
  - Infrastructure: adding a load balancer with at least one extra node, this will help alliviate some load compared to only using one node.
 - DB: optimizing queries is also an option